/*
 * Autor: Lucas Marassi Cipriano Pereira
 * Control Projeto - Sistema de Acompanhamento de Demandas
 * Projeto Integrador 2
 */

import { Request, Response } from "express";
import Projeto from "../model/Projeto";

export default class ProjetoControl {

    // Lista todos os projetos.
    async projeto_read_all_control(request: Request, response: Response) {
        const projeto = new Projeto();
        const resultado = await projeto.readAll();

        const objResposta = {
            cod: 1,
            status: true,
            msg: "Executado com sucesso",
            projetos: resultado,
        };
        response.status(200).send(objResposta);
    }
}
