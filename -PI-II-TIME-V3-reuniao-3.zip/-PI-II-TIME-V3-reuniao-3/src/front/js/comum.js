/* Autor: Lucas Marassi Cipriano Pereira
   Funcoes comuns usadas pelas telas de demanda - Sistema de Acompanhamento de Demandas
   Projeto Integrador 2 */

// Cor da etiqueta (badge do Bootstrap) para cada status.
const CLASSES_STATUS = {
    "Aberta": "bg-primary",
    "Em andamento": "bg-warning text-dark",
    "Em revisao": "bg-info text-dark",
    "Concluida": "bg-success",
    "Cancelada": "bg-secondary"
};

// Cor da etiqueta para cada prioridade.
const CLASSES_PRIORIDADE = {
    "Critica": "bg-danger",
    "Alta": "bg-warning text-dark",
    "Media": "bg-primary",
    "Baixa": "bg-secondary"
};

// Chama a API e devolve a resposta ja convertida de JSON para objeto.
// "async" e "await": a funcao espera o servidor responder antes de continuar.
async function buscarJSON(url, opcoes) {
    const resposta = await fetch(url, opcoes);
    return await resposta.json();
}

// Converte "2026-09-19" ou "2026-09-19 10:03:00" para "19/09/2026".
function dataBR(texto) {
    if (!texto) {
        return "-";
    }
    const partes = texto.substring(0, 10).split("-"); // ["2026", "09", "19"]
    return partes[2] + "/" + partes[1] + "/" + partes[0];
}

// Converte "2026-09-19 10:03:00" para "19/09/2026 10:03".
function dataHoraBR(texto) {
    if (!texto) {
        return "-";
    }
    return dataBR(texto) + " " + texto.substring(11, 16);
}

// Cria uma etiqueta colorida (<span class="badge ...">texto</span>).
// Usa textContent (e nao innerHTML) para o texto nunca ser interpretado como HTML.
function criarBadge(texto, classes) {
    const span = document.createElement("span");
    span.className = "badge " + (classes || "bg-secondary");
    span.textContent = texto;
    return span;
}

// Procura em uma lista (de projetos ou usuarios) o nome que tem o id informado.
function nomePorId(lista, campoId, id) {
    const item = lista.find(function (i) { return i[campoId] === id; });
    return item ? item.nome : "-";
}

// Mostra uma mensagem de erro (ou de sucesso) na caixa de aviso da tela.
function mostrarMensagem(texto, tipo) {
    const caixa = document.getElementById("mensagem");
    caixa.className = "alert alert-" + (tipo || "danger");
    caixa.textContent = texto;
}
