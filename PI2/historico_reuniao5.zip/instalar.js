/* Integrador local para o patch de historico. Nao executa git, commit ou push. */
const fs = require("fs");
const path = require("path");

const ROOT = process.cwd();
const novos = path.join(__dirname, "novos");
const arquivosNovos = [
  "PI2/src/back/model/Historico.ts",
  "PI2/src/back/control/HistoricoControl.ts",
  "PI2/src/back/router/HistoricoRouter.ts",
  "PI2/src/front/js/historico.js"
];

function ler(relativo) {
  const arquivo = path.join(ROOT, relativo);
  if (!fs.existsSync(arquivo)) throw new Error(`Arquivo esperado nao encontrado: ${relativo}`);
  return fs.readFileSync(arquivo, "utf8");
}

function substituirUnico(texto, antigo, novo, descricao) {
  const qtd = texto.split(antigo).length - 1;
  if (qtd !== 1) throw new Error(`Nao foi possivel integrar '${descricao}': encontrei ${qtd} ocorrencias do trecho esperado.`);
  return texto.replace(antigo, novo);
}

function main() {
  if (!fs.existsSync(path.join(ROOT, "PI2/src/back/app.ts"))) {
    throw new Error("Execute com o diretorio atual na raiz do repositorio (onde existe PI2/).");
  }

  for (const relativo of arquivosNovos) {
    if (fs.existsSync(path.join(ROOT, relativo))) {
      throw new Error(`O arquivo ${relativo} ja existe. O instalador nao vai sobrescrever trabalho existente.`);
    }
    if (!fs.existsSync(path.join(novos, relativo))) throw new Error(`Arquivo do pacote ausente: ${relativo}`);
  }

  // Primeiro monta todas as alteracoes em memoria e valida os trechos. Nenhum arquivo
  // do projeto e escrito ate todos os pontos de integracao terem sido encontrados.
  let app = ler("PI2/src/back/app.ts");
  app = substituirUnico(app,
    'import ComentarioRouter from "./router/ComentarioRouter";\n',
    'import ComentarioRouter from "./router/ComentarioRouter";\nimport HistoricoRouter from "./router/HistoricoRouter";\n',
    "import do HistoricoRouter");
  app = substituirUnico(app,
    'app.use("/comentario", acesso.identificar_Usuario, comentarioRoteador.criarRotasComentario());\n',
    'app.use("/comentario", acesso.identificar_Usuario, comentarioRoteador.criarRotasComentario());\n\nconst historicoRoteador = new HistoricoRouter();\napp.use("/historico", acesso.identificar_Usuario, historicoRoteador.criarRotasHistorico());\n',
    "rota de historico");

  let control = ler("PI2/src/back/control/DemandaControl.ts");
  control = substituirUnico(control,
    'import Demanda from "../model/Demanda";\n',
    'import Demanda from "../model/Demanda";\nimport Historico from "../model/Historico";\n',
    "import do Historico");
  control = substituirUnico(control,
    'export default class DemandaControl {\n',
    'export default class DemandaControl {\n' +
    '    private normalizarHistorico(valor: unknown): string | null {\n' +
    '        if (valor === null || valor === undefined || valor === "") return null;\n' +
    '        if (valor instanceof Date) return valor.toISOString().slice(0, 10);\n' +
    '        return String(valor);\n' +
    '    }\n\n' +
    '    private async registrarHistorico(idDemanda: number, idUsuario: number, campo: string, anterior: unknown, novo: unknown) {\n' +
    '        await new Historico().registrar(idDemanda, idUsuario, campo, this.normalizarHistorico(anterior), this.normalizarHistorico(novo));\n' +
    '    }\n',
    "helpers do historico");
  control = substituirUnico(control,
    '        const resultado = isCreated ? await demanda.readByID() : [];\n',
    '        const resultado = isCreated ? await demanda.readByID() : [];\n' +
    '        if (isCreated && resultado[0]) {\n' +
    '            const criado = resultado[0];\n' +
    '            const idUsuario = Number(response.locals.usuario.id_usuario);\n' +
    '            const idDemanda = Number(criado.id_demanda);\n' +
    '            await this.registrarHistorico(idDemanda, idUsuario, "demanda", null, "Criada");\n' +
    '            await this.registrarHistorico(idDemanda, idUsuario, "status", null, criado.status ?? "Aberta");\n' +
    '            const camposIniciais: Array<[string, unknown]> = [["titulo", criado.titulo], ["descricao", criado.descricao], ["tipo", criado.tipo], ["prioridade", criado.prioridade], ["projeto", criado.id_projeto], ["responsavel", criado.id_responsavel], ["prazo", criado.prazo]];\n' +
    '            for (const [campo, valor] of camposIniciais) await this.registrarHistorico(idDemanda, idUsuario, campo, null, valor);\n' +
    '        }\n',
    "historico da criacao");
  control = substituirUnico(control,
    '        // TODO: validar o prazo na API de feriados, registrar as mudancas no historico\n' +
    '        // e conferir se o perfil do usuario pode editar (depende do login).\n' +
    '        const isUpdated = await demanda.update();\n' +
    '        // Busca a demanda de novo para devolver os dados atualizados.\n' +
    '        const resultado = isUpdated ? await demanda.readByID() : [];\n',
    '        const consultaAnterior = new Demanda();\n' +
    '        consultaAnterior.id = demanda.id;\n' +
    '        const dadosAnteriores = await consultaAnterior.readByID();\n' +
    '        const isUpdated = await demanda.update();\n' +
    '        const resultado = isUpdated ? await demanda.readByID() : [];\n' +
    '        if (isUpdated && dadosAnteriores[0] && resultado[0]) {\n' +
    '            const antes = dadosAnteriores[0];\n' +
    '            const depois = resultado[0];\n' +
    '            const idUsuario = Number(response.locals.usuario.id_usuario);\n' +
    '            const campos: Array<{ nome: string; coluna: string }> = [{ nome: "titulo", coluna: "titulo" }, { nome: "descricao", coluna: "descricao" }, { nome: "tipo", coluna: "tipo" }, { nome: "prioridade", coluna: "prioridade" }, { nome: "projeto", coluna: "id_projeto" }, { nome: "responsavel", coluna: "id_responsavel" }, { nome: "prazo", coluna: "prazo" }];\n' +
    '            for (const campo of campos) {\n' +
    '                const valorAnterior = this.normalizarHistorico(antes[campo.coluna]);\n' +
    '                const valorNovo = this.normalizarHistorico(depois[campo.coluna]);\n' +
    '                if (valorAnterior !== valorNovo) await this.registrarHistorico(Number(demanda.id), idUsuario, campo.nome, valorAnterior, valorNovo);\n' +
    '            }\n' +
    '        }\n',
    "historico da edicao");
  control = substituirUnico(control,
    '        // O model faz o UPDATE no banco.\n        const isUpdated = await demanda.updateStatus();\n',
    '        const consultaAnterior = new Demanda();\n' +
    '        consultaAnterior.id = demanda.id;\n' +
    '        const dadosAnteriores = await consultaAnterior.readByID();\n' +
    '        const isUpdated = await demanda.updateStatus();\n' +
    '        if (isUpdated && dadosAnteriores[0]) {\n' +
    '            await this.registrarHistorico(Number(demanda.id), Number(response.locals.usuario.id_usuario), "status", dadosAnteriores[0].status, demanda.status);\n' +
    '        }\n',
    "historico do status/cancelamento");

  let html = ler("PI2/src/front/demanda-detalhes.html");
  html = substituirUnico(html,
    '<p class="text-muted mb-0">O historico sera ligado quando a parte de historico da API for feita.</p>',
    '<div id="lista-historico" class="mb-0">Carregando historico...</div>',
    "area de historico da tela");
  html = substituirUnico(html,
    '    <script src="js/comentarios.js"></script>\n',
    '    <script src="js/comentarios.js"></script>\n    <script src="js/historico.js"></script>\n',
    "script de historico na tela");

  // Todos os trechos foram validados: agora aplica os arquivos novos e as integracoes.
  for (const relativo of arquivosNovos) {
    const origem = path.join(novos, relativo);
    const destino = path.join(ROOT, relativo);
    fs.mkdirSync(path.dirname(destino), { recursive: true });
    fs.copyFileSync(origem, destino);
  }
  fs.writeFileSync(path.join(ROOT, "PI2/src/back/app.ts"), app, "utf8");
  fs.writeFileSync(path.join(ROOT, "PI2/src/back/control/DemandaControl.ts"), control, "utf8");
  fs.writeFileSync(path.join(ROOT, "PI2/src/front/demanda-detalhes.html"), html, "utf8");
  console.log("Historico integrado apenas na copia local. Nenhum commit ou push foi feito.");
  console.log("Revise o diff e rode npm run build dentro de PI2 antes de testar.");
}

try { main(); } catch (erro) { console.error("Integracao cancelada:", erro.message); process.exitCode = 1; }
