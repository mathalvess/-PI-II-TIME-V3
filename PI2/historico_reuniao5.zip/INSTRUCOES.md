# Patch minimo conforme o escopo do PI II

## O que este pacote altera

Na branch `reunião-5`, comentarios, busca/filtros, ordenacao, dashboard, CRUD, transicoes e cancelamento sem exclusao fisica ja aparecem implementados. Este pacote **nao refaz essas partes**. Acrescenta somente o historico automatico que faltava: registro na criacao, nas mudancas de campos e nas mudancas de status (incluindo cancelamento), endpoint protegido para consulta e exibicao na tela de detalhes.

A validacao de feriados nacionais ja foi desenvolvida na branch `feriados-pedro`. Nao dupliquei essa implementacao aqui; ela deve ser integrada/revisada pela equipe no fluxo de branches/PRs existente.

## Integrar localmente, sem GitHub

1. Faca backup da sua pasta local e confirme que esta na branch `reunião-5`.
2. Extraia este ZIP na raiz da sua copia local do repositorio.
3. Execute `node instalar.js` na raiz do repositorio. O script somente edita arquivos locais; nao executa `git`, commit ou push. Ele se recusa a sobrescrever arquivos novos ja existentes e valida os trechos esperados antes de gravar.
4. Revise `git diff` manualmente. Dentro de `PI2`, execute `npm run build` e teste com o MySQL configurado.

## Testes minimos

- Criar demanda e confirmar no banco os registros de criacao/status/campos em `historico`.
- Editar titulo, descricao, tipo, prioridade, projeto, responsavel e prazo; confirmar que so os campos alterados geram registros.
- Alterar status e cancelar; confirmar que a demanda permanece no banco e o status fica registrado no historico.
- Abrir os detalhes e conferir autor, campo, data/hora e valores anterior/novo.
- Tentar consultar o historico de demanda sem permissao e confirmar que o acesso e negado.

O pacote foi preparado com base no codigo consultado na branch `reunião-5`, mas nao foi compilado nem testado contra o banco real desta maquina. Nao considere concluido antes de executar estes testes.
